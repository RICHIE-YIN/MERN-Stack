import React from "react";
import {
  Routes,
  Route,
  Link
} from "react-router-dom";
import NavBar from "./components/Navbar";
import Home from "./components/Home";
import Teams from "./components/Teams";
import "./App.css";
import Landing from "./components/Landing";
import SearchBar from "./components/Searchbar";
import People from "./components/People";
import Vehicles from "./components/Vehicles";
import Species from "./components/Species";
import Spaceships from "./components/Starships";
import Planets from "./components/Planets";
import Films from "./components/Films";
import Starships from "./components/Starships";

function App() {
  return (
    <div>
      <SearchBar />
      <Routes>
        <Route path="/:text" element={<Landing />} />
        <Route path="/:text/:textcolor/:color" element={<Landing />} />
        <Route path="/home" element={<Home />} />
        <Route path="/films" element={<Films />} />
        <Route path="/films/:num" element={<Films />} />
        <Route path="/people" element={<People />} />
        <Route path="/people/:num" element={<People />} />
        <Route path="/planets" element={<Planets />} />
        <Route path="/planets/:num" element={<Planets />} />
        <Route path="/starships" element={<Starships />} />
        <Route path="/starships/:num" element={<Starships />} />
        <Route path="/species" element={<Species />} />
        <Route path="/species/:num" element={<Species />} />
        <Route path="/vehicles" element={<Vehicles />} />
        <Route path="/vehicles/:num" element={<Vehicles />} />
      </Routes>
    </div>
  );
}

export default App