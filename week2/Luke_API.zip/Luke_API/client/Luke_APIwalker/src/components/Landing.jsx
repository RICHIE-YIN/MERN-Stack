import React from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";

const Landing = () => {
    const {text, textcolor, color} = useParams()
    return (
    <div>
        <h1 style={{color: textcolor, backgroundColor: color}}>{text} </h1>
    </div>
    );
}

export default Landing