import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import axios from 'axios'


const People = () => {
    const [people, setPeople] = useState([])
    const {num} = useParams()


    useEffect(() => {
        axios.get(`https://swapi.dev/api/people/${num}/?format=json`)
        .then((response) => {
            console.log("This is our get request: ", response.data)
            setPeople(response.data)
        })
        .catch((err) => {
            console.log("This is our catch error: ", err)
        })
    }, [num])

    return (
    <div>
        <h1>People</h1>
        <p>Name: {people.name}</p>
        <p>Height: {people.height}</p>
        <p>Mass: {people.mass}</p>
        <p>Hair Color: {people.hair_color}</p>
    </div>
    );
}

export default People