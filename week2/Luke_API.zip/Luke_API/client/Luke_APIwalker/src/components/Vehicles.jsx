import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import axios from 'axios'


const Vehicles = () => {
    const [vehicles, setVehicles] = useState([])

    useEffect(() => {
        axios.get(`https://swapi.dev/api/vehicles/?format=json`)
        .then((response) => {
            console.log("This is our get request: ", response.data)
            setVehicles(response.data.results)
        })
        .catch((err) => {
            console.log("This is our catch error: ", err)
        })
    }, [])

    return (
    <div>
            {
                vehicles.map((car, idx) => {
                    return (
                        <div keys={idx}>
                            <p>Name: {car.name}</p>
                            <p>Model: {car.model}</p>
                            <p>Manufacturer: {car.manufacturer}</p>
                            <p>Length: {car.length}</p>
                            <p>___________________________________________________________</p>
                        </div>
                    )
                })
            }
    </div>
    );
}

export default Vehicles