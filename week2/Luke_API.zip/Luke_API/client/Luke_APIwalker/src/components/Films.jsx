import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import axios from 'axios'


const Films = () => {
    const [films, setFilms] = useState([])
    const {num} = useParams()


    useEffect(() => {
        axios.get(`https://swapi.dev/api/films/${num}/?format=json`)
        .then((response) => {
            console.log("This is our get request: ", response.data)
            setFilms(response.data)
        })
        .catch((err) => {
            console.log("This is our catch error: ", err)
        })
    }, [num])

    return (
    <div>
        <h1>Films</h1>
        <p>Name: {films.title}</p>
        <p>Director: {films.director}</p>
        <p>Episode: {films.episode_id}</p>
        <p>Release Date: {films.release_date}</p>
    </div>
    );
}

export default Films