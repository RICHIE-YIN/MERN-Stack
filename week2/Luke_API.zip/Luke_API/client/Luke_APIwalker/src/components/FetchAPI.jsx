import React, {useState} from 'react'
import {useNavigate} from 'react-router-dom'
import axios from 'axios'

const FetchAPI = () => {
    const [pokemons, setPokemons] = useState([])
    
    const axiosData = () => {
    axios.get("https://pokeapi.co/api/v2/pokemon?limit=807&offset=0").then(res => {
        setPokemons(res.data.results) });
        
}


    // FETCH METHOD
    // const fetchData = () => {
    //     fetch("https://pokeapi.co/api/v2/pokemon?limit=807&offset=0")
    //     .then((res) => {
    //         return res.json()
    //     })
    //     .then((res) => {
    //         console.log("Getting data from our API: ", res)
    //         setPokemons(res.results)
    //     })
    //     .catch((error) => {
    //         console.log("This is coming from my catch error: ", error)
    //     })
    //     console.log("This is called Asynchronous code")
    // }


    return (
        <div >
            <h1>AxiosAPI</h1>
            <button onClick={axiosData}>Click!</button>
            {
                pokemons.map((pokemon, idx) => {
                    return (
                        <div keys={idx}>
                            <p>{pokemon.name}</p>
                        </div>
                    )
                })
            }
        </div>
    )
}

export default FetchAPI