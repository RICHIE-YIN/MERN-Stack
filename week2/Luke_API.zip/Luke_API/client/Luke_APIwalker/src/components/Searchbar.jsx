import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

const SearchBar = (props) => {
    const [searchFor, setSearchFor] = useState()
    const [num, setNum] = useState()
    const navigate = useNavigate();

    const searchStarwars = (e) => {
    e.preventDefault();
    navigate(`/${searchFor}/${num}`);
}

    return (
        <div>
        <h1>Test</h1>
        <form onSubmit={ searchStarwars }>
            <label for="list">Choose a car:</label>
                <select name="cars" onChange={ (e) => setSearchFor(e.target.value)} value={searchFor}>
                    <option value="planets">Planets</option>
                    <option value="starships">Starships</option>
                    <option value="vehicles">Vehicles</option>
                    <option value="people">People</option>
                    <option value="films">Films</option>
                    <option value="species">Species</option>
                </select>
                <label>Quanity:</label>
                <input type="number" onChange={ (e) => setNum(e.target.value)} value={num}></input>
                <input type="submit" value="Search!" />
        </form>
    </div>
    );
}

export default SearchBar