import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import axios from 'axios'

const Species = () => {
    const [species, setSpecies] = useState([])
    const {num} = useParams()


    useEffect(() => {
        axios.get(`https://swapi.dev/api/species/${num}/?format=json`)
        .then((response) => {
            console.log("This is our get request: ", response.data)
            setSpecies(response.data)
        })
        .catch((err) => {
            console.log("This is our catch error: ", err)
        })
    }, [num])

    return (
    <div>
        <h1>Species</h1>
        <p>Name: {species.name}</p>
        <p>Classification: {species.classification}</p>
        <p>Designation: {species.designation}</p>
        <p>Skin Colors: {species.skin_colors}</p>
    </div>
    );
}

export default Species