import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import axios from 'axios'

const Starships = () => {
    const [starships, setStarships] = useState([])
    const {num} = useParams()


    useEffect(() => {
        axios.get(`https://swapi.dev/api/starships/${num}/?format=json`)
        .then((response) => {
            console.log("This is our get request: ", response.data)
            setStarships(response.data)
        })
        .catch((err) => {
            console.log("This is our catch error: ", err)
        })
    }, [num])

    return (
    <div>
        <h1>Starships</h1>
        <p>Name: {starships.name}</p>
        <p>Model: {starships.model}</p>
        <p>Manufacturer: {starships.manufacturer}</p>
        <p>Length: {starships.length}</p>
    </div>
    );
}

export default Starships