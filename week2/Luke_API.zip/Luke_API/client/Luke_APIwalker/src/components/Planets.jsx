import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import axios from 'axios'

const Planets = () => {
    const [planets, setPlanets] = useState([])
    const {num} = useParams()


    useEffect(() => {
        axios.get(`https://swapi.dev/api/planets/${num}/?format=json`)
        .then((response) => {
            console.log("This is our get request: ", response.data)
            setPlanets(response.data)
        })
        .catch((err) => {
            console.log("This is our catch error: ", err)
        })
    }, [num])

    return (
    <div>
        <h1>Planets</h1>
        <p>Name: {planets.name}</p>
        <p>Rotation Period: {planets.rotation_period}</p>
        <p>Diameter: {planets.diameter}</p>
        <p>Climate: {planets.climate}</p>
    </div>
    );
}

export default Planets