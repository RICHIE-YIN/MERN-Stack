import React from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";

const Teams = () => {
    const {city} = useParams()
    return (
    <div>
        <h1 style={{color: "blue"}}>Teams</h1>
        <h3> Welcome to {city} </h3>
        <Link to={"/"}>Go Home</Link>
    </div>
    );
}

export default Teams