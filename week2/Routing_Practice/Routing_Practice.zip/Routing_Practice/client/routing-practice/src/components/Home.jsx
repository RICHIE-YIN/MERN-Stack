import React from "react";
import { Link } from "react-router-dom";

const Home = (props) => {
    return (
    <div>
        <h1 style={{color: "blue"}}>Welcome</h1>
    </div>
    );
}

export default Home