import React from "react";
import {
  Routes,
  Route,
  Link
} from "react-router-dom";
import NavBar from "./components/Navbar";
import Home from "./components/Home";
import Teams from "./components/Teams";
import "./App.css";
import Landing from "./components/Landing";

function App() {
  return (
    <div>
      <Routes>
        <Route path="/:text" element={<Landing />} />
        <Route path="/:text/:textcolor/:color" element={<Landing />} />
        <Route path="/home" element={<Home />} />
      </Routes>
    </div>
  );
}

export default App