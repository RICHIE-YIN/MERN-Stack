import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import axios from 'axios';
import DeleteButton from './DeleteButton';
    
const AuthorList = (props) => {
    const [author, setAuthor] = useState([]);
    
    useEffect(() => {
        axios.get('http://localhost:8000/api/allauthors')
            .then(res => setAuthor(res.data));
    }, [])
    
    const removeFromDom = authorId => {
        setAuthor(author.filter(author => author._id != authorId))
    }
    
    return (
        <div>
            {author
            .sort((a,b) => {
            if(a.name < b.name) {return -1;}
            if(a.name > b.name) {return 1;}
            return 0;
            })
            .map((author, idx) => {
                return (
                    <table key={idx}>
                        <tr>
                            <th>Author</th>
                            <th>Actions available</th>
                        </tr>
                        <tr>
                            <td>
                            <Link to={"/" + author._id}>
                            {author.name}
                            </Link>
                            </td>
                            <td>
                            <Link to={"/edit/" + author._id}>
                            Edit
                            </Link>
                            <DeleteButton authorId={author._id} successCallback={()=>removeFromDom(author._id)}/>
                            </td>
                        </tr>
                    </table>
                )
            })}
        </div>
    );
}
    
export default AuthorList;

