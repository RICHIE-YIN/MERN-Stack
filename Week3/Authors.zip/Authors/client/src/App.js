import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Main from './views/Main';
import Detail from './views/Detail';
import Edit from './views/Edit';
import CreateAuthor from './views/CreateAuthor';
import NoAuthor from './views/NoAuthor';

function App() {
    return (
      <div className="App">
        <Routes>
            <Route element={<Main/>} path="/" />
            <Route element={<CreateAuthor/>} path="/new" />
            <Route element={<NoAuthor/>} path="/error" />
            <Route element={<Detail/>} path="/:id" />
            <Route element={<Edit/>} path="/edit/:id"/>
        </Routes>                         
      </div>
    );
}
export default App;