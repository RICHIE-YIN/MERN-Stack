import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useParams, Link } from "react-router-dom";
    
const Detail = (props) => {
    const [author, setAuthor] = useState({})
    const { id } = useParams();

    const { removeFromDom } = props;    
    const deleteAuthor = (authorId) => {
        axios.delete(`http://localhost:8000/api/author/${id}`)
            .then(res => {
                removeFromDom(authorId)
            })
            .catch(err => console.error(err));
        }
    
    useEffect(() => {
        axios.get(`http://localhost:8000/api/author/${id}`)
            .then(res => setAuthor(res.data))
            .catch(err => console.error(err));
    }, []);
    
    return (
        <div>
            <p>Author: {author.name}</p>
            <Link to={`/author/${author._id}/edit`}>
                Edit
            </Link>
            <Link to={`/author`}>
            <button onClick={(e)=>{deleteAuthor(author._id)}}>
                Delete
            </button>
            </Link>
        </div>
    )
}
    
export default Detail;

