import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import axios from 'axios';
import AuthorForm from '../components/AuthorForm';
import AuthorList from '../components/AuthorList';
export default () => {
    const [author, setAuthor] = useState([]);
    const [loaded, setLoaded] = useState(false);
    useEffect(() => {
        axios.get('http://localhost:8000/api/allauthors')
            .then(res =>{
                setAuthor(res.data)
                setLoaded(true);
            });
    }, [])
    const removeFromDom = authorId => {
        setAuthor(author.filter(author => author._id != authorId));
    }

    return (
        <div>
            <h1>Favorite Authors</h1>
            <Link to={"/new"}>
                Add an author
            </Link>
            <h5>We have quotes by:</h5>
            {loaded && <AuthorList author={author} removeFromDom={removeFromDom}/>}
        </div>
    )
}