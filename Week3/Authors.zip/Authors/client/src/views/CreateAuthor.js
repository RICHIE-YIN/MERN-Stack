import React, { useEffect, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import AuthorForm from '../components/AuthorForm';

export default () => {
    const navigate = useNavigate()
    const [errors, setErrors] = useState([]);
    const { id } = useParams();
    const [author, setAuthor] = useState();

    const createAuthor = (author) => {
        axios.post('http://localhost:8000/api/author', author)
        .then((res) => {
            console.log("response", res)
            if(res.data.errors){
                setErrors(res.data.errors)
            } else{
                navigate("/")
            }
        }) 
        .catch(err=>{
            console.log("error", err)
            // const errorResponse = err.response; // Get the errors from err.response.data
            // const errorArr = []; // Define a temp error array to push the messages in
            // for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
            //     errorArr.push(errorResponse[key].message)
            // }
            // console.log(errorArr)
            // // Set Errors
            // setErrors([...errors, errorArr]);
        })            
}

    return (
        <div>
            <h1>Add a new Author</h1>
            <h5>{errors.name ? errors.name.message:""}</h5>
            {/* {errors.map((err, index) => <p key={index}> {err} </p>)} */}
            <AuthorForm onSubmitProp={createAuthor} initialAuthor="" />
        </div>
    )
}