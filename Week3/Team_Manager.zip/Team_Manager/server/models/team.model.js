const mongoose = require('mongoose');

const TeamSchema = new mongoose.Schema({
    name: { 
        type: String,
        required: [true, "Name is required"],
        minLength: [3, "Name must be 3 characters long"]
    },
    position: { 
        type: String,
        required: [true, "Position is required"],
        minLength: [5, "Position must be 5 characters long"]
    },
    playing: {
        type: Boolean,
        required: [false]
    },
    notplaying: {
        type: Boolean,
        required: [false]
    },
    undecided: {
        type: Boolean,
        required: [false]
    }
}, { timestamps: true });
module.exports.Team = mongoose.model('Team', TeamSchema);