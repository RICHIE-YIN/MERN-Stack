import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import axios from 'axios';
import DeleteButton from './DeleteButton';
import Table from 'react-bootstrap/Table';
    
const TeamList = (props) => {
    const [team, setTeam] = useState([]);
    
    useEffect(() => {
        axios.get('http://localhost:8000/api/allteams')
            .then(res => setTeam(res.data));
    }, [])
    
    const removeFromDom = teamId => {
        setTeam(team.filter(team => team._id != teamId))
    }
    
    return (
        <div>
        <Table striped bordered hover>
            <thead>
                <th>Team Name</th>
                <th>Preferred Position</th>
                <th>Actions</th>
            </thead>
            {team
            .sort((a,b) => {
            if(a.name < b.name) {return -1;}
            if(a.name > b.name) {return 1;}
            return 0;
            })
            .map((team, idx) => {
                return (
                <tr key={idx}>
                    <td><Link to={"/" + team._id}>
                    {team.name}
                    </Link></td>
                    <td>{team.position}</td>
                    <td>
                        {/* <Link to={"/edit/" + team._id}>
                        Edit
                        </Link> */}
                        <DeleteButton
                        teamId={team._id}
                        successCallback={() => removeFromDom(team._id)}
                        />
                    </td>
                </tr>
                );
            })}
        </Table>
    </div>
    );
}
    
export default TeamList;

