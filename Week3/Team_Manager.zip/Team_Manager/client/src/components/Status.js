import React, { useEffect, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from 'axios';


export default props => {
    const { initialPlaying, initialNotPlaying, initialUndecided, onSubmitProp } = props;
    const [playing, setPlaying] = useState(initialPlaying);
    const [notPlaying, setNotPlaying] = useState(initialNotPlaying);
    const [undecided, setUndecided] = useState(initialUndecided);
    const [errors, setErrors] = useState([]);
    const { id } = useParams();
    const navigate = useNavigate()

    const onSubmitHandler = e => {
        e.preventDefault();
        onSubmitProp({playing, notPlaying, undecided});
    }
    const updateTeam = team => {
        axios.put('http://localhost:8000/api/team/' + id, team)
            .then((res) => {navigate("/team")}) 
            .catch(err=>{
                const errorResponse = err.response.data.errors; // Get the errors from err.response.data
                const errorArr = []; // Define a temp error array to push the messages in
                for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
                    errorArr.push(errorResponse[key].message)
                }
                // Set Errors
                setErrors(errorArr);
            })            
    }

    return (
        <form onSubmit={updateTeam}>
            <input type="radio" name="gender" value={playing}
                    onChange={(e) => { setPlaying(e.target.value) }} /> Playing
            <input type="radio" name="gender" value={notPlaying}
                    onChange={(e) => { setNotPlaying(e.target.value) }}/> Not Playing
            <input type="radio" name="gender" value={undecided}
                    onChange={(e) => { setUndecided(e.target.value) }}/> Undecided
        </form>
    )
}


