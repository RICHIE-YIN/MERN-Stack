import React, { useState } from 'react'
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

export default props => {
    const { teamId, successCallback } = props;
    const [show, setShow] = useState(false)
    const handleClose = () => setShow(false)
    const handleShow = () => setShow(true)

    const deleteTeam = e => {
        axios.delete('http://localhost:8000/api/team/' + teamId)
            .then(res=>{
                successCallback();
            })
    }
    
    
    return (
        <>
        <Button variant="danger" onClick={handleShow}>
            Delete
        </Button>
    
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
            <Modal.Title>Confirm Delete</Modal.Title>
            </Modal.Header>
            <Modal.Body>Are you sure you want to delete {teamId.name}?</Modal.Body>
            <Modal.Footer>
            <Button variant="primary" onClick={handleClose}>
                Close
            </Button>
            <Button variant="danger" onClick={deleteTeam}>
                Delete
            </Button>
            </Modal.Footer>
        </Modal>
        </>
        //EXAMPLE FOR JUST DELETE
        // <button onClick={deleteTeam}>
        //     Delete
        // </button>
    )
}
