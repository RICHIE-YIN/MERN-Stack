import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';

export default props => {
    const { initialName, initialPosition, onSubmitProp } = props;
    const [name, setName] = useState(initialName);
    const [position, setPosition] = useState(initialPosition);
    const [nameErrors, setNameErrors] = useState("Name must be 3 characters");
    const [positionErrors, setPositionErrors] = useState("Position must be 3 characters");
    const onSubmitHandler = e => {
        e.preventDefault();
        onSubmitProp({name, position});
    }

    const ValidationName = (e) => {
        setName(e.target.value)
        if (name.length > 1){
            return setNameErrors("")
        } else if (name.length < 8) {
            setNameErrors("Name must be 3 characters")
        }
    }

    return (
        <form onSubmit={onSubmitHandler}>
            <p>
                <label>Name:</label><br />
                <input
                    type="text"
                    name="name" value={name}
                    onChange={ValidationName} />
            </p>
            <p>
                <label>Preferred Position:</label><br />
                <input
                    type="text"
                    name="position" value={position}
                    onChange={(e) => { setPosition(e.target.value) }} />
            </p>
            {!nameErrors?<button type="submit">Submit</button>:""}
            <button>
                    <Link to={"/players/list"}>
                    Cancel
                    </Link>
                </button>
        </form>
    )
}