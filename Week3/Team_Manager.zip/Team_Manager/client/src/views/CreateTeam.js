import React, { useEffect, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import TeamForm from '../components/TeamForm';

export default () => {
    const navigate = useNavigate()
    const [errors, setErrors] = useState([]);
    const { id } = useParams();
    const [team, setTeam] = useState();

    const createTeam = (team) => {
        axios.post('http://localhost:8000/api/team', team)
        .then((res) => {
            console.log("response", res)
            if(res.data.errors){
                setErrors(res.data.errors)
            } else{
                navigate("/players/list")
            }
        }) 
        .catch(err=>{
            console.log("error", err)
            // const errorResponse = err.response; // Get the errors from err.response.data
            // const errorArr = []; // Define a temp error array to push the messages in
            // for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
            //     errorArr.push(errorResponse[key].message)
            // }
            // console.log(errorArr)
            // // Set Errors
            // setErrors([...errors, errorArr]);
        })            
}

    return (
        <div>
            <h5>{errors.name ? errors.name.message:""}</h5>
            <h5>{errors.position ? errors.position.message:""}</h5>
            <Link to={"/players/list"}>Manage Players</Link>|<Link to={"/players/list"}>Manage Players Status</Link>
            {/* <h1>Favorite Teams</h1> */} <br></br>
            <Link to={"/players/list"}>List</Link>|<Link to={"/players/addplayer"}>Add a team</Link>
            {/* <h1>Add a new Team</h1> */}
            {/* {errors.map((err, index) => <p key={index}> {err} </p>)} */}
            <TeamForm onSubmitProp={createTeam} initialTeam="" />
        </div>
    )
}