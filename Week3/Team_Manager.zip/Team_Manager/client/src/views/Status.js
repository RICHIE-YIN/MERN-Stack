import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import axios from 'axios';
import DeleteButton from '../components/DeleteButton';
    
const GameStatus = (props) => {
    const [team, setTeam] = useState([]);
    
    useEffect(() => {
        axios.get('http://localhost:8000/api/allteams')
            .then(res => setTeam(res.data));
    }, [])

    // const updateTeam = team => {
    //     axios.put('http://localhost:8000/api/team/' + id, team)
    //         .then((res) => {navigate("/team")}) 
    //         .catch(err=>{
    //             const errorResponse = err.response.data.errors; // Get the errors from err.response.data
    //             const errorArr = []; // Define a temp error array to push the messages in
    //             for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
    //                 errorArr.push(errorResponse[key].message)
    //             }
    //             // Set Errors
    //             setErrors(errorArr);
    //         })            
    // }
    
    const removeFromDom = teamId => {
        setTeam(team.filter(team => team._id != teamId))
    }
    
    return (
        <div>
        <table>
            <thead>
                <th>Team Name</th>
                <th>Preferred Position</th>
                <th>Actions</th>
            </thead>
            {team
            .sort((a,b) => {
            if(a.name < b.name) {return -1;}
            if(a.name > b.name) {return 1;}
            return 0;
            })
            .map((team, idx) => {
                return (
                <tr key={idx}>
                    <td><Link to={"/" + team._id}>
                    {team.name}
                    </Link></td>
                    <td>{team.position}</td>
                    <td>
                        <Link to={"/edit/" + team._id}>
                        Edit
                        </Link>
                        <DeleteButton
                        teamId={team._id}
                        successCallback={() => removeFromDom(team._id)}
                        />
                    </td>
                </tr>
                );
            })}
        </table>
    </div>
    );
}
    
export default GameStatus;

