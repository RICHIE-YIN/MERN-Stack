import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useParams, Link } from "react-router-dom";
import Button from 'react-bootstrap/Button';
    
const Detail = (props) => {
    const [team, setTeam] = useState({})
    const { id } = useParams();
    const [show, setShow] = useState(false)
    const handleClose = () => setShow(false)
    const handleShow = () => setShow(true)

    const { removeFromDom } = props;    
    const deleteTeam = (teamId) => {
        axios.delete(`http://localhost:8000/api/team/${id}`)
            .then(res => {
                removeFromDom(teamId)
            })
            .catch(err => console.error(err));
        }
    
    useEffect(() => {
        axios.get(`http://localhost:8000/api/team/${id}`)
            .then(res => setTeam(res.data))
            .catch(err => console.error(err));
    }, []);
    
    return (
        <div>
            <p>Team: {team.name}</p>
            <p>Position: {team.position}</p>
            {/* <Link to={`/edit/${team._id}`}>
                Edit
            </Link>
            <Link to={`/team`}>
            <button onClick={(e)=>{deleteTeam(team._id)}}>
                Delete
            </button>
            </Link> */}
        </div>
    )
}
    
export default Detail;

