import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useParams, useNavigate, Link } from 'react-router-dom';
import TeamForm from '../components/TeamForm';
import Status from '../components/Status';
const Update = (props) => {
    
    const navigate = useNavigate()
    const { id } = useParams();
    const [team, setTeam] = useState();
    const [loaded, setLoaded] = useState(false);
    const [errors, setErrors] = useState([])
    
    useEffect(() => {
        axios.get(`http://localhost:8000/api/team/${id}`)
            .then(res => {
                console.log(res.data)
                if(res.data.reason){
                    navigate("/error")
                } 
                setTeam(res.data);
                setLoaded(true);
            })
            .catch((err) => {
                navigate("/error")
            });
    }, [id]);
    
    const updateTeam = team => {
        axios.put('http://localhost:8000/api/team/' + id, team)
            .then((res) => {navigate("/team")}) 
            .catch(err=>{
                const errorResponse = err.response.data.errors; // Get the errors from err.response.data
                const errorArr = []; // Define a temp error array to push the messages in
                for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
                    errorArr.push(errorResponse[key].message)
                }
                // Set Errors
                setErrors(errorArr);
            })            
    }
    
    return (
        <div>
            <h1>Favorite teams</h1>
            <Link to={"/"}>
                Home
            </Link>
            <h5>Edit this Team</h5>
            {errors.map((err, index) => <p key={index}> {err} </p>)}
            {loaded && (
                <>
                    <TeamForm
                        onSubmitProp={updateTeam}
                        initialName={team.name}
                        initialPosition={team.position}
                    />
                    <Status />
                    </>
            )}
        </div>
    )
}
    
export default Update;