import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import axios from 'axios';
import TeamForm from '../components/TeamForm';
import TeamList from '../components/TeamList';
import Status from '../components/Status';
export default () => {
    const [team, setTeam] = useState([]);
    const [loaded, setLoaded] = useState(false);
    useEffect(() => {
        axios.get('http://localhost:8000/api/allteams')
            .then(res =>{
                setTeam(res.data)
                setLoaded(true);
            });
    }, [])
    const removeFromDom = teamId => {
        setTeam(team.filter(team => team._id != teamId));
    }

    return (
        <div>
            <h1>Hi</h1>
            <Link to={"/players/list"}>Manage Players</Link>|<Link to={"/players/list"}>Manage Players Status</Link>
            {/* <h1>Favorite Teams</h1> */} <br></br>
            <Link to={"/players/list"}>List</Link>|<Link to={"/players/addplayer"}>Add a team</Link>
            <h5>Team</h5>
            <table>
                <tr>
                    <th>
                        Team
                    </th>
                    <th>
                        Actions
                    </th>
                </tr>
                <tr>
                    <td>
                        {loaded && <TeamList team={team} removeFromDom={removeFromDom}/>}
                    </td>
                    <td>
                        <Status />
                    </td>
                </tr>


            </table>

        </div>
    )
}