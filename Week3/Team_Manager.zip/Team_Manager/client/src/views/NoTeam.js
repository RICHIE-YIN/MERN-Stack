import React from "react";
import {Link} from 'react-router-dom'

const NoTeam = () => {
    return (
        <div>
            <p>
            We're sorry, but we could not find the team you are looking for. 
            Would you like to add this team to our database?
            </p>
            <Link to="/players/addplayer">Create a team</Link>
        </div>
    );
}

export default NoTeam;