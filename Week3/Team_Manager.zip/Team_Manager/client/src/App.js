import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Routes, Route } from 'react-router-dom';
import Main from './views/Main';
import Detail from './views/Detail';
import Edit from './views/Edit';
import CreateTeam from './views/CreateTeam';
import NoTeam from './views/NoTeam';
import Button from 'react-bootstrap/esm/Button';
import Status from './components/Status';
import GameStatus from './views/GameStatus';

function App() {
    return (
      <div className="App">
        <Button> Hi </Button>
        <Routes>
            <Route element={<Main/>} path="/players/list" />
            <Route element={<CreateTeam/>} path="/players/addplayer" />
            <Route element={<NoTeam/>} path="/error" />
            <Route element={<Detail/>} path="/:id" />
            <Route element={<Edit/>} path="/edit/:id"/>
            <Route element={<GameStatus/>} path="/status/game"/>
            <Route element={<Status/>} path="/status"/>
        </Routes>                         
      </div>
    );
}
export default App;