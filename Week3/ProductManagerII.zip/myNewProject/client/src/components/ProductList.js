import React from 'react'
import axios from 'axios';
import { Link } from "react-router-dom";
// import { useNavigate } from 'react-router-dom'

// const navigate = useNavigate();
    
const ProductList = (props) => {
    return (
        <div>
            {props.product.map( (product, i) =>
            <Link to={product._id}>
                <p key={i}>
                    {product.title}
                    {/* {product.price},  */}
                    {/* {product.description} */}
                </p>
            </Link>
            )}
        </div>
    )
}
    
export default ProductList;